

from flask import Flask, render_template, request, redirect, session
import mysql.connector
app = Flask(__name__)
app.secret_key = "secret_key"


db = mysql.connector.connect(
    host="localhost",
    user="root",
    port="3306",
    password="Welcome@1",
    database="loginpage"
)
cursor = db.cursor()


@app.route("/")
def login():
    return render_template("login.html")


@app.route("/auth", methods=["POST"])
def auth():
    username = request.form["username"]
    password = request.form["password"]
    cursor.execute("SELECT * FROM users WHERE username=%s AND password=%s", (username, password))
    user = cursor.fetchone()
    if user:
        session["username"] = user[0]
        return redirect("/dashboard")
    else:
        return "Invalid login credentials."
    

@app.route("/dashboard")
def dashboard():
    if "username" in session:
        return f"Welcome, {session['username']}!"
    else:
        return redirect("/")


@app.route("/logout")
def logout():
    session.pop("username", None)
    return redirect("/")


    
    